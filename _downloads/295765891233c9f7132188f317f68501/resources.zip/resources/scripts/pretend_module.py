def get_multiplier():
    return 2.
